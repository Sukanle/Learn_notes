#pragma once

#include <version>

#include "static/reflect.hpp"   // IWYU pragma: keep

namespace SRefl = reflect::Static;
// namespace DRefl = reflect::Dynamic;

// clang-format off
#if TEMPLATE_STRING_SUPPORTED
#define make_field_traits(var) var
#else
#define make_field_traits(var) var,#var
#endif
#define RFS_OBJ_BEGIN(type)                              \
    template<> struct SRefl::TypeInfo<type> {            \
        using class_type = type;                         \
        static constexpr std::string_view _name = #type; \
        struct Registry {
#define RFS_OBJ_VAR(VAR)                                \
    static constexpr auto _##VAR =                      \
        SRefl::field_traits<decltype(&class_type::VAR), \
        false, MAKE_TEMPLATE_STRING(#VAR)>{make_field_traits(&class_type::VAR)};
#define RFS_OBJ_FUNC(FN)                               \
    static constexpr auto _##FN =                      \
        SRefl::field_traits<decltype(&class_type::FN), \
        true, MAKE_TEMPLATE_STRING(#FN)>{make_field_traits(&class_type::FN)};
#define RFS_OBJ_END() \
        };            \
    };
#define RFS_NOR_VAR(VAR)                                                  \
    SRefl::field_traits<decltype(VAR), false, MAKE_TEMPLATE_STRING(#VAR)> \
        {make_field_traits(VAR)}
#define RFS_OVR_FN(FN, FN_TYPE)                                   \
    SRefl::field_traits<FN_TYPE, true, MAKE_TEMPLATE_STRING(#FN)> \
        {make_field_traits(FN)}
#define RFS_NOR_FN(FN) RFS_OVR_FN(FN, decltype(FN))
// clang-format on
