#include "reflect.hpp"   // IWYU pragma: keep
#include <iostream>
#include <map>
#include <string>
#include <type_traits>
#include <vector>

class Person final {
public:
    std::string family;
    bool isFemale = false;
    // NOLINTNEXTLINE
    void IntroduceMyself() const volatile&& noexcept {
        puts("This is IntroduceMyself().");
    }
    [[nodiscard]] bool getFemale() const {
        // puts("This is isFemale().");
        return isFemale;
    }
    bool getMarried(Person& other) {
        bool success = other.isFemale != isFemale;
        family = (success) ? " Mrs." + other.family : "Mr." + other.family;
        puts("Married!");
        return success;
    }
};
enum class MyEnum : uint8_t { Val0 = 0, Val1 = 1 };

namespace reflect::Dynamic {
namespace factory {
template<typename T> class Enum;
}   // namespace factory
class Numberic;
class Type {
public:
    static std::map<std::string_view, const Type*> list;

    enum class Kind : uint8_t { Numberic, Enum, Class, Unkown };
    virtual ~Type() = default;
    explicit Type(Kind kind, std::string_view name)
        : _kind(kind)
        , _name{name} {}
    [[nodiscard]] const std::string& getName() const { return _name; }
    [[nodiscard]] const Kind& getKind() const { return _kind; }
    template<typename T>
    // requires std::is_base_of_v<Type, T>
    [[nodiscard]] const T* as() const {
        return static_cast<const T*>(this);
    }

private:
    template<typename T> friend class factory::Enum;
    Kind _kind;
    std::string _name;
};
class Numberic final : public Type {
public:
    enum class Kind : uint8_t {
        Unknown = 0,
        Int8 = 1,
        Int16 = 2,
        Int32 = 4,
        Int64 = 8,
        Float = 16,
        Double = 32,
        Long_Double = 64
    };
    Numberic(Kind kind, bool is_signed)
        : Type{Type::Kind::Numberic, to_string(kind)}
        , _kind{kind}
        , _is_signed(is_signed) {
        Type::list[getName()] = static_cast<Type*>(this);
    }

    template<typename T>
    // requires std::is_arithmetic_v<T>
    static Numberic create() {
        return Numberic{to_Kind<T>(), std::is_signed_v<T>};
    }
    [[nodiscard]] Kind getKind() const { return _kind; }
    [[nodiscard]] bool getSigned() const { return _is_signed; }

private:
    Kind _kind;
    bool _is_signed;
    static std::string to_string(Kind kind) {
        switch (kind) {
            case Kind::Int8:        return "int8";
            case Kind::Int16:       return "Int16";
            case Kind::Int32:       return "int32";
            case Kind::Int64:       return "int64";
            case Kind::Float:       return "float";
            case Kind::Double:      return "double";
            case Kind::Long_Double: return "long double";
            default:                return "Unknown";
        }
    }
    template<typename T>
    // requires std::is_arithmetic_v<T>
    static Kind to_Kind() {
        return std::is_integral_v<T> ? static_cast<Kind>(sizeof(T))
                                     : static_cast<Kind>(sizeof(T) * 4);
    }
};
class Enum final : public Type {
private:
    using value_type = int32_t;
    using enum_map = std::map<std::string_view, value_type>;
    enum_map _map;

public:
    explicit Enum()
        : Type{Kind::Unkown, "Unknown-Enum"} {
        Type::list[getName()] = static_cast<Type*>(this);
    }
    explicit Enum(std::string_view name)
        : Type{Kind::Enum, name} {}
    template<typename T> void add(std::string_view name, T value) {
        _map[name] = static_cast<value_type>(value);
        Type::list[getName()] = static_cast<Type*>(this);
    }
    [[nodiscard]] const enum_map& getMap() const { return _map; }
};
struct MemVar {
    std::string _name;
    const Type* type;
};
struct MemFunc {
    std::string _name;
    const Type* _retType;
    std::vector<const Type*> paramTypes;
};

class Class final : public Type {
public:
    explicit Class(const std::string& name)
        : Type(Type::Kind::Class, name) {}

private:
    std::vector<MemVar> _vars;
    std::vector<MemFunc> _fns;
};
namespace factory {

template<typename T> class Numberic final {
public:
    static Numberic& Instance() {
        static Numberic inst{reflect::Dynamic::Numberic::create<T>()};
        return inst;
    }
    [[nodiscard]] const reflect::Dynamic::Numberic& Info() const {
        return _info;
    }

private:
    reflect::Dynamic::Numberic _info;
    explicit Numberic(reflect::Dynamic::Numberic&& info)
        : _info{std::move(info)} {}
};
template<typename T> class Enum final {
public:
    static Enum& Instance() {
        static Enum inst;
        return inst;
    }
    [[nodiscard]] const reflect::Dynamic::Enum& Info() const { return _info; }
    Enum& Regist(std::string_view name) {
        _info._name = name;
        return *this;
    };
    template<typename U> Enum& add(std::string_view name, U value) {
        _info.add(name, value);
        return *this;
    }
    void UnRegist() { _info = reflect::Dynamic::Enum{}; }

private:
    reflect::Dynamic::Enum _info;
};
class Trivial final {
public:
    static Trivial& Instance() {
        static Trivial inst;
        return inst;
    }
};
template<typename T> class factory final {
public:
    static auto& getFactory() {
        if constexpr (std::is_arithmetic_v<T>)
            return Numberic<T>::Instance();
        else if constexpr (std::is_enum_v<T>)
            return Enum<T>::Instance();
        else if constexpr (std::is_class_v<T>)
            return Enum<T>::Instance();
        else
            return Trivial::Instance();
    }
};
}   // namespace factory
template<typename T> auto& Register() {
    return factory::factory<T>::getFactory();
}
template<typename T> const Type* getType() {
    return &Register<T>().Info();
}
const Type* getType(std::string_view type) {
    return Type::list.find(type)->second;
}
std::map<std::string_view, const Type*> Type::list{};
}   // namespace reflect::Dynamic

inline const char* strbool(bool value) {
    return value ? "true" : "false";
}

// RFS_OBJ_BEGIN(Person)
//     RFS_OBJ_VAR(isFemale)
//     RFS_OBJ_FUNC(getFemale)
// RFS_OBJ_END()

template<> struct reflect::Static::TypeInfo<Person> {
    using class_type = Person;
    static constexpr ::std::string_view _name = "Person";
    struct Registry {
        static constexpr auto _isFemale =
            SRefl::field_traits<decltype(&class_type::isFemale), false,
                                MAKE_TEMPLATE_STRING("isFemale")>{
                &class_type::isFemale
#if !TEMPLATE_STRING_SUPPORTED
                ,
                "&class::isFemale"
#endif
            };
        static constexpr auto _getFemale =
            SRefl::field_traits<decltype(&class_type::getFemale), true,
                                MAKE_TEMPLATE_STRING("getFemale")>{
                &class_type::getFemale
#if !TEMPLATE_STRING_SUPPORTED
                ,
                "&class_type::getFemale"
#endif
            };
    };
    constexpr TypeInfo() = default;
};

// void print() {
//     printf("hello world\n");
// }

int print(int A) {
    return printf("hello world, %d\n", A);
}
int print_over() {
    return printf("hello world\n");
}
void print_over(int A) {
    printf("hello world, %d\n", A);
}

template<typename T> void print_over(T A) {
    std::cout << A << "\n";
}
int main() {
    int Var0 = 0;
    int Var1 = 1;
    auto Var0Info = RFS_NOR_VAR(Var0);
    // auto Var0Info =
    //     SRefl::field_traits<decltype(Var0), false, 0>{print_over(), "Var0"};
    auto Var1Info = RFS_NOR_VAR(Var1);
    // auto Var1Info =
    //     SRefl ::field_traits<decltype(Var1), false, 0>{Var1, "Var1"};
    auto Fn0 = RFS_NOR_FN(print);
    auto Fn1 = RFS_OVR_FN(print_over, void(int));

    // const reflect::Dynamic::Type* typeinfo =
    //     // reflect::Dynamic::getType<MyEnum>();
    //     reflect::Dynamic::getType("MyEnum");
    // const reflect::Dynamic::Enum* enuminfo =
    //     typeinfo->as<reflect::Dynamic::Enum>();
    // printf("%s\n", typeinfo->getName().c_str());
    //
    // for (auto& item : enuminfo->getMap())
    //     printf("%s: %d\n", item.first.data(), item.second);
    Person person;
    // void (Person::*fn_ptr)() const volatile&& noexcept =
    //     &Person::IntroduceMyself;
    // char cperson[sizeof(Person)];
    // NOLINTBEGIN
    Person* person_ptr = (Person*)malloc(sizeof(Person));
    auto info = reflect::Static::type_info<Person>();
    using PersonInfo = reflect::Static::TypeInfo<Person>;
    // using IsFemaleInfo = decltype(PersonInfo::Registry::isFemale_info);
    puts("*************************************************************");
    puts("------- Testing for Forced Conversion ptr (support for memory "
         "control) --------");
    person_ptr->isFemale = false;
    printf("person_ptr->isFemale: %d\n", person_ptr->isFemale);
    person_ptr->isFemale = true;
    printf("person_ptr->isFemale: %d\n", person_ptr->isFemale);
    person_ptr->*PersonInfo::Registry::_isFemale._ptr = false;
    printf("person_ptr->*PersonInfo::Registry::_isFemale._ptr: %s = %d\n",
           PersonInfo::Registry::_isFemale.getName().data(),
           person_ptr->*PersonInfo::Registry::_isFemale._ptr);
    puts("------- Testing for member ptr --------");
    printf("person.*PersonInfo::Registry::_isFemale._ptr: %s = %d\n",
           PersonInfo::Registry::_isFemale.getName().data(),
           person.*PersonInfo::Registry::_isFemale._ptr);
    printf("person.isFemale: %d\n", person.isFemale);
    person.isFemale = true;
    printf("person.*PersonInfo::Registry::_isFemale._ptr: %s = %d\n",
           PersonInfo::Registry::_isFemale.getName().data(),
           person.*PersonInfo::Registry::_isFemale._ptr);
    printf("person.isFemale: %d\n", person.isFemale);
    puts("------- Testing for member function --------");
    printf("(person.*PersonInfo::Registry::_getFemale._ptr)(): %s = %d\n",
           PersonInfo::Registry::_isFemale.getName().data(),
           (person.*PersonInfo::Registry::_getFemale._ptr)());
    printf("person.getFemale(): %d\n", person.getFemale());
    puts("*************************************************************");
    puts("------- Testing for normal variable--------");
    printf("\"%s\" = %d\n", Var0Info.getName().data(), Var0Info._ptr);
    puts("------- Testing for normal function--------");
    printf("\"%s\": ", Fn0.getName().data());
    Fn0._ptr(Var0Info._ptr);
    printf("\"%s\": ", Fn1.getName().data());
    Fn1._ptr(Var1Info._ptr);
    // NOLINTEND

    return 0;
}
