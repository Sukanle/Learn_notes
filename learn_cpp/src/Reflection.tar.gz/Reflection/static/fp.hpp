#pragma once
#include "base_fp.hpp"
#include <cstdint>


namespace refective::fp {

template<typename TypeList, uint8_t N>
using nth = typename base::fp::nth<TypeList, N>::type;
template<typename TypeList>
using head = typename base::fp::head<TypeList>::type;
template<typename TypeList>
using tail = typename base::fp::tail<TypeList>::type;
template<typename TypeList>
using other = typename base::fp::other<TypeList>::type;


template<typename TypeList, typename T>
using push = typename base::fp::push<T, TypeList>::type;
template<typename TypeList> using pop = base::fp::pop<TypeList>::type;
template<typename... Lists>
using concat = typename base::fp::concat<Lists...>::type;


template<typename TypeList>
inline constexpr uint8_t size = base::fp::size<TypeList>::value;
template<typename TypeList, template<typename> class F>
inline constexpr uint8_t count =
    base::fp::count<TypeList, F, TypeList::count - 1>::value;

template<typename TypeList, template<typename> class F, typename T>
using map = typename base::fp::map<TypeList, F, T>::type;
template<template<typename> class F, typename TypeList>
using transform = typename base::fp::transform<F, TypeList>::type;
template<template<typename> class F, typename List>
using flat_map = typename base::fp::flat_map<F, List>::type;
template<typename TypeList, template<typename...> class F>
using filter = base::fp::filter<TypeList, F>::type;
template<typename TypeList, template<typename...> class F, typename Arg>
using filter_args = base::fp::filter<TypeList, F, Arg>::type;

template<typename TypeList>
using unique = typename base::fp::unique<TypeList>::type;
template<typename TypeList, typename Target, uint8_t Index = 0>
inline constexpr auto find_index =
    base::fp::find_index<TypeList, Target, Index>::value;
template<typename TypeList, typename Target>
using remove = typename base::fp::remove<TypeList, Target>::type;
}   // namespace refective::fp
