#pragma once
#include <cstddef>
#include <cstdint>
#include <type_traits>

namespace refective {
#ifndef REFECTIVE_TYPE_LIST
#define REFECTIVE_TYPE_LIST
template<typename... Args> struct type_list {
    static constexpr uint8_t count = sizeof...(Args);
};
#endif
namespace base::fp {
template<typename T, uint8_t N> struct nth;
template<typename T, typename... Remains>
struct nth<type_list<T, Remains...>, 0> {
    using type = T;
};
template<typename T, typename... Remains, uint8_t N>
struct nth<type_list<T, Remains...>, N> {
    using type = typename nth<type_list<Remains...>, N - 1>::type;
};
template<typename T> struct head;
template<typename T, typename... Remains>
struct head<type_list<T, Remains...>> {
    using type = T;
};
template<typename T> struct other;
template<typename T, typename... Remains>
struct other<type_list<T, Remains...>> {
    using type = type_list<Remains...>;
};
template<typename TypeList> struct tail {
    static_assert(TypeList::count > 0, "Error: type_list is empty");
    using type = typename nth<TypeList, TypeList::count - 1>::type;
};

template<typename, typename> struct push;
template<typename... Args, typename T> struct push<T, type_list<Args...>> {
    using type = type_list<T, Args...>;
};

template<typename> struct pop;
template<typename T> struct pop<type_list<T>> {
    using type = type_list<>;
};
template<typename T, typename... Remains> struct pop<type_list<T, Remains...>> {
    using type = push<T, typename pop<type_list<Remains...>>::type>;
};

template<typename... Lists> struct concat;
template<typename... Ts> struct concat<type_list<Ts...>> {
    using type = type_list<Ts...>;
};
template<typename... Ts1, typename... Ts2, typename... Rest>
struct concat<type_list<Ts1...>, type_list<Ts2...>, Rest...> {
    using type = typename concat<type_list<Ts1..., Ts2...>, Rest...>::type;
};

template<typename> struct size;
template<typename... Args> struct size<type_list<Args...>> {
    static constexpr uint8_t value = sizeof...(Args);
};
template<typename, template<typename> class, uint8_t> struct count;
template<typename T, typename... Remains, template<typename> class F>
struct count<type_list<T, Remains...>, F, 0> {
    static constexpr uint8_t value = (F<T>::value ? 1 : 0);
};
template<typename T, typename... Remains, template<typename> class F, uint8_t N>
struct count<type_list<T, Remains...>, F, N> {
    static constexpr uint8_t value =
        (F<T>::value ? 1 : 0) + count<type_list<Remains...>, F, N - 1>::value;
};

template<typename, template<typename> class, typename> struct map;
template<typename... Remains, template<typename> class F, typename T>
struct map<type_list<Remains...>, F, T> {
    using type =
        type_list<std::conditional_t<F<Remains>::value, T, Remains>...>;
};

template<typename, template<typename...> typename, typename = void>
struct filter;
template<template<typename...> class F, typename AdditionalArg>
struct filter<type_list<>, F, AdditionalArg> {
    using type = type_list<>;
};
template<typename T, typename... Remains, template<typename...> class F>
struct filter<type_list<T, Remains...>, F,
              std::enable_if_t<F<T>::value != F<T>::value>> {
    using type = std::conditional_t<
        F<T>::value,
        typename push<T, typename filter<type_list<Remains...>, F>::type>::type,
        typename filter<type_list<Remains...>, F>::type>;
};

template<template<typename> class F, typename List> struct transform;
template<template<typename> class F, typename... Ts>
struct transform<F, type_list<Ts...>> {
    using type = type_list<typename F<Ts>::type...>;
};

template<template<typename> class F, typename List> struct flat_map;
template<template<typename> class F, typename... Ts>
struct flat_map<F, type_list<Ts...>> {
    using type = concat<typename F<Ts>::type...>;
};

template<typename T, typename... Remains, template<typename...> class F,
         typename AdditionalArg>
struct filter<type_list<T, Remains...>, F, AdditionalArg> {
    using type = std::conditional_t<
        F<T, AdditionalArg>::value,
        typename push<T, typename filter<type_list<Remains...>, F,
                                         AdditionalArg>::type>::type,
        typename filter<type_list<Remains...>, F, AdditionalArg>::type>;
};

template<typename List> struct unique;
template<> struct unique<type_list<>> {
    using type = type_list<>;
};
template<typename T, typename... Rest> struct unique<type_list<T, Rest...>> {
private:
    using rest_unique = typename unique<type_list<Rest...>>::type;

    template<typename U, typename = void> struct contains : std::false_type {};

    template<typename... Us>
    struct contains<type_list<Us...>,
                    std::void_t<decltype((std::is_same_v<T, Us> || ...))>>
        : std::bool_constant<(std::is_same_v<T, Us> || ...)> {};

public:
    using type = std::conditional_t<contains<rest_unique>::value, rest_unique,
                                    typename push<T, rest_unique>::type>;
};

template<typename List, typename Target, uint8_t Index = 0> struct find_index;
template<typename Target, uint8_t Index>
struct find_index<type_list<>, Target, Index> {
    static_assert(Index != 0, "Error: Target type not found in type_list");
    static constexpr int8_t value = -1;
};
template<typename T, typename... Rest, typename Target, uint8_t Index>
struct find_index<type_list<T, Rest...>, Target, Index> {
    static constexpr int8_t value =
        std::is_same_v<T, Target>
            ? Index
            : find_index<type_list<Rest...>, Target, Index + 1>::value;
};

template<typename List, typename Target> struct remove;
template<typename Target> struct remove<type_list<>, Target> {
    using type = type_list<>;
};
template<typename T, typename... Rest, typename Target>
struct remove<type_list<T, Rest...>, Target> {
private:
    using rest_removed = typename remove<type_list<Rest...>, Target>::type;

public:
    using type = std::conditional_t<std::is_same_v<T, Target>, rest_removed,
                                    typename push<T, rest_removed>::type>;
};

}   // namespace base::fp
}   // namespace refective
