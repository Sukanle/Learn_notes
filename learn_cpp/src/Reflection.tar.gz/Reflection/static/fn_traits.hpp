#pragma once

#include <cstdint>
#include <tuple>

#include "template_string.hpp"

namespace reflect::Static {

enum class Modifier : uint8_t {
    Const = 0,
    Volatile,
    Lvalue,
    Rvalue,
    Noexcept,
    Count
};
template<typename> struct fn_type;
template<typename Ret, typename... Args> struct fn_type<Ret(Args...)> {
    using return_t = Ret;
    using args_t = std::tuple<Args...>;
    using fn_ptr = Ret (*)(Args...);
    using function_t = Ret(Args...);
};
template<typename Ret, typename... Args>
struct fn_type<Ret (*)(Args...)> : fn_type<Ret(Args...)> {};
template<typename Ret, typename Class, typename... Args>
struct fn_type<Ret (Class::*)(Args...)> {
    using return_t = Ret;
    using class_t = Class;
    using args_t = std::tuple<Args...>;
};

template<typename, DEFAULT_TEMPLATE_STRING(, "")> struct base_fn_traits;

template<NORMAL_TEMPLATE_STRING(Name), typename Ret, typename... Args>
struct base_fn_traits<Ret(Args...), Name> : fn_type<Ret(Args...)> {
    static constexpr auto name = NameAccessor<Name>();
    static constexpr bool is_member = false;
    static constexpr uint8_t params_count = sizeof...(Args);
};
template<NORMAL_TEMPLATE_STRING(Name), typename Ret, typename... Args>
struct base_fn_traits<Ret (*)(Args...), Name>
    : base_fn_traits<Ret(Args...), Name> {};
template<NORMAL_TEMPLATE_STRING(Name), typename Ret, typename Class,
         typename... Args>
struct base_fn_traits<Ret (Class::*)(Args...), Name>
    : fn_type<Ret (Class::*)(Args...)> {
    static constexpr auto name = NameAccessor<Name>();
    static constexpr bool is_member = true;
    static constexpr bool is_static = false;
    static constexpr uint8_t params_count = sizeof...(Args);
};

template<typename, DEFAULT_TEMPLATE_STRING(, "")> struct fn_traits;

template<NORMAL_TEMPLATE_STRING(Name), typename Ret, typename... Args>
struct fn_traits<Ret(Args...), Name> : base_fn_traits<Ret(Args...), Name> {};

template<NORMAL_TEMPLATE_STRING(Name), typename Ret, typename... Args>
struct fn_traits<Ret (*)(Args...), Name> : fn_traits<Ret(Args...), Name> {};

// NOLINTBEGIN
#define DEF_FN_TRAITS(modifier, ...)                                     \
    template<NORMAL_TEMPLATE_STRING(Name), typename Ret, typename Class, \
             typename... Args>                                           \
    struct fn_traits<Ret (Class::*)(Args...) modifier, Name>             \
        : base_fn_traits<Ret (Class::*)(Args...), Name> {                \
        using m_fn_ptr = Ret (Class::*)(Args...) modifier;               \
        using function_t = Ret(Class, Args...) modifier;                 \
        static constexpr bool is_modifie[(uint8_t)Modifier::Count]{      \
            __VA_ARGS__};                                                \
    };

DEF_FN_TRAITS(, 0, 0, 0, 0, 0)
DEF_FN_TRAITS(const, 1, 0, 0, 0, 0)
DEF_FN_TRAITS(volatile, 0, 1, 0, 0, 0)
DEF_FN_TRAITS(const volatile, 1, 1, 0, 0, 0)
DEF_FN_TRAITS(&, 0, 0, 1, 0, 0)
DEF_FN_TRAITS(const&, 1, 0, 1, 0, 0)
DEF_FN_TRAITS(volatile&, 0, 1, 1, 0, 0)
DEF_FN_TRAITS(const volatile&, 1, 1, 1, 0, 0)
DEF_FN_TRAITS(&&, 0, 0, 0, 1, 0)
DEF_FN_TRAITS(const&&, 1, 0, 0, 1, 0)
DEF_FN_TRAITS(volatile&&, 0, 1, 0, 1, 0)
DEF_FN_TRAITS(const volatile&&, 1, 1, 0, 1, 0)
DEF_FN_TRAITS(noexcept, 0, 0, 0, 0, 1)
DEF_FN_TRAITS(const noexcept, 1, 0, 0, 0, 1)
DEF_FN_TRAITS(volatile noexcept, 0, 1, 0, 0, 1)
DEF_FN_TRAITS(const volatile noexcept, 1, 1, 0, 0, 1)
DEF_FN_TRAITS(& noexcept, 0, 0, 1, 0, 1)
DEF_FN_TRAITS(const& noexcept, 1, 0, 1, 0, 1)
DEF_FN_TRAITS(volatile& noexcept, 0, 1, 1, 0, 1)
DEF_FN_TRAITS(const volatile& noexcept, 1, 1, 1, 0, 1)
DEF_FN_TRAITS(&& noexcept, 0, 0, 0, 1, 1)
DEF_FN_TRAITS(const&& noexcept, 1, 0, 0, 1, 1)
DEF_FN_TRAITS(volatile&& noexcept, 0, 1, 0, 1, 1)
DEF_FN_TRAITS(const volatile&& noexcept, 1, 1, 0, 1, 1)
// NOLINTEND

#undef DEF_FN_TRAITS
}   // namespace reflect::Static
