#pragma once
#include "base_reflect.hpp"
#include <string_view>

namespace reflect::Static {

template<template<typename...> class F, typename... Args>
inline constexpr bool NOT = !F<Args...>::value;

template<class T> struct TypeInfo;

#ifndef reflect_TYPE_LIST
#define reflect_TYPE_LIST
template<typename... Args> struct type_list {
    static constexpr uint8_t count = sizeof...(Args);
};
#endif

template<typename T> struct is_type_list : std::false_type {};
template<typename... Ts>
struct is_type_list<type_list<Ts...>> : std::true_type {};

template<typename T>
inline constexpr bool is_type_list_v = is_type_list<T>::value;

template<typename... Args>
inline constexpr uint8_t type_list_count = type_list<Args...>::count;

template<typename T> struct cv_combinations {
    using type = type_list<T, std::add_const_t<T>, std::add_volatile_t<T>,
                           std::add_cv_t<T>>;
};
template<typename T> struct ref_combinations {
    using type = type_list<T, std::add_lvalue_reference_t<T>,
                           std::add_rvalue_reference_t<T>>;
};

template<typename T>
using cv_combinations_t = typename cv_combinations<T>::type;
template<typename T>
using ref_combinations_t = typename ref_combinations<T>::type;

template<typename, bool is_fn, DEFAULT_TEMPLATE_STRING(, "")>
struct field_traits;

template<typename T, NORMAL_TEMPLATE_STRING(Name)>
struct field_traits<T, true, Name>
    : base_field_traits<T, is_Fn_Kind<T>(), Name> {
#if TEMPLATE_STRING_SUPPORTED
    using traits = base_field_traits<T, is_Fn_Kind<T>(), Name>;
    explicit field_traits(T& ptr)
        : base_field_traits<T, is_Fn_Kind<T>(), Name>{ptr} {}
    explicit consteval field_traits(T&& ptr)
        : base_field_traits<T, is_Fn_Kind<T>(), Name>{std::forward<T>(ptr)} {}
    [[nodiscard]] static consteval std::string_view getName() {
        return traits::fn_traits::base_fn_traits::name.data();
    }
#else
    std::string_view _name;
    // explicit field_traits(T* ptr, std::string_view name)
    //     : base_field_traits<T, is_Fn_Kind<T>(), Name>{ptr}
    //     , _name(name) {}
    explicit field_traits(T& ptr, std::string_view name)
        : base_field_traits<T, is_Fn_Kind<T>(), Name>{ptr}
        , _name(name) {}
    explicit consteval field_traits(T&& ptr, std::string_view name)
        : base_field_traits<T, is_Fn_Kind<T>(), Name>{std::move(ptr)}
        , _name(name) {}
    [[nodiscard]] consteval std::string_view getName() const { return _name; }
#endif
};
template<typename T, NORMAL_TEMPLATE_STRING(Name)>
struct field_traits<T, false, Name>
    : base_field_traits<T, is_Var_Kind<T>(), Name> {
#if TEMPLATE_STRING_SUPPORTED
    using traits = base_field_traits<T, is_Fn_Kind<T>(), Name>;
    explicit field_traits(T& ptr)
        : base_field_traits<T, is_Var_Kind<T>(), Name>{ptr} {}
    explicit consteval field_traits(T&& ptr)
        : base_field_traits<T, is_Var_Kind<T>(), Name>{std::forward<T>(ptr)} {}
    [[nodiscard]] consteval static std::string_view getName() {
        return traits::var_traits::base_var_traits::name.data();
    }
#else
    std::string_view _name;
    explicit field_traits(T& ptr, std::string_view name)
        : base_field_traits<T, is_Var_Kind<T>(), Name>{ptr}
        , _name{name} {}
    explicit consteval field_traits(T&& ptr, std::string_view name)
        : base_field_traits<T, is_Var_Kind<T>(), Name>(std::forward<T>(ptr))
        , _name(name) {}
    [[nodiscard]] consteval std::string_view getName() const { return _name; }
#endif
};

template<typename T> consteval auto type_info() {
    return TypeInfo<T>{};
}
}   // namespace reflect::Static

// #include "fp.hpp"   // IWYU pragma: keep
